dichiara_attaccanti <- function(){}
  
dichiara_bloccanti <- function(){}

abilita_post_danno <- function(){}