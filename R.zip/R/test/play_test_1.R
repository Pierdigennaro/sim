source("R/carica_tutto.R")
carica_tutto(path = "R")

gioco_test <- gioca_partita_test(
  max_turni = 10,
  seed      = 42,
  verbose   = TRUE
)

# Alla fine puoi ispezionare lo stato:
str(gioco_test)

mazzo_elfi  <- crea_mazzo_test_elfi()
mazzo_burn  <- crea_mazzo_test_burn()

player1 <- crea_giocatore(
  mazzo      = mazzo_elfi,
  comandante = NULL,   # se vuoi, puoi passare elfo come comandante
  nome       = "Pippo - Elfi"
)

player2 <- crea_giocatore(
  mazzo      = mazzo_burn,
  comandante = NULL,
  nome       = "Mario - Burn"
)



gioco<- crea_partita(player1,player2)
