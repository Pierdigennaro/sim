source("R/carica_tutto.R")
carica_tutto("R")
run_core_smoke_tests()
